# CloudComputing_A7
This repository contains similar code to A6, however using AWS serverless tecnology
