module.exports.datastores = {

  default: {
    adapter: 'sails-mysql',
    url: 'mysql://root:mihirpatel@database-cloud-a6-company-y.cphyahymvakt.us-east-1.rds.amazonaws.com:3306/company_y',
    ssl:true
  },
};
